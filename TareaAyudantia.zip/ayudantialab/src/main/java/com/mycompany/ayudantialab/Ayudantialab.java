

package com.mycompany.ayudantialab;

import java.util.ArrayList;
import java.util.Scanner;

public class Ayudantialab {

    private ArrayList<String> tarea;

    public Ayudantialab() {
        tarea = new ArrayList<>();
    }

    public void addTask(String task) {
        tarea.add(task);
    }

    public void removeTask(int index) {
        tarea.remove(index);
    }

    public void displayTasks() {
        if (tarea.isEmpty()) {
            System.out.println("No hay tareas para mostrar");
        } else {
            System.out.println("Tareas:");
            for (int i = 0; i < tarea.size(); i++) {
                System.out.println(i + 1 + ". " + tarea.get(i));
            }
        }
    }

    public static void main(String[] args) {
        menu();
    }

    public static void menu() {
        Scanner scanner = new Scanner(System.in);
        Ayudantialab listaTareas = new Ayudantialab();

        while (true) {
            System.out.println("\nSelecciona una opción:");
            System.out.println("1. Añade una tarea");
            System.out.println("2. Elimina una tarea");
            System.out.println("3. Mostrar tareas");
            

            int opcion = scanner.nextInt();
            scanner.nextLine(); 

            switch (opcion) {
                case 1:
                    System.out.print("Ingresa una tarea ");
                    String task = scanner.nextLine();
                    listaTareas.addTask(task);
                    break;
                case 2:
                    listaTareas.displayTasks();
                    if (!listaTareas.tarea.isEmpty()) {
                        System.out.print("Elige el numero de una tarea para eliminarla ");
                        int index = scanner.nextInt();
                        listaTareas.removeTask(index - 1);
                    }
                    break;
                case 3:
                    listaTareas.displayTasks();
                    break;
               
                default:
                    System.out.println("Opcion invalida.");
            }
        }
    }
}
